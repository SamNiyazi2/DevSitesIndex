declare var dataService_instance: {
    doSetup: (currentApplication: string) => void;
};
export { dataService_instance };
