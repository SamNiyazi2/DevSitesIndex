// 09/18/2019 03:20 am - SSN - [20190917-0929] - [015] - Adding paging for angular lists
//# sourceMappingURL=IColumnBag.js.map