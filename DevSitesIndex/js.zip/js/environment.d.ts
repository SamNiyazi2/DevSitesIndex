export declare const environment: {
    appInsights: {
        instrumentationKey: string;
    };
};
