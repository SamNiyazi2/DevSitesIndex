import * as angular from 'angular';
declare var pagingDirective_instance: {
    pagingDirective_angular_module: angular.IModule;
};
export { pagingDirective_instance };
