import * as angular from 'angular';
declare var headerWithSort_instance: {
    headerWithSort_angular_module: angular.IModule;
};
export { headerWithSort_instance };
