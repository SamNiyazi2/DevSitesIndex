/// <reference types="angular" />
declare var jobStatusDisplayDirective_instance: {
    jobStatusDisplay: import("angular").IModule;
};
export { jobStatusDisplayDirective_instance };
