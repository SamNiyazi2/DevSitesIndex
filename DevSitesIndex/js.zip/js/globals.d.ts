import * as angular from "angular";
declare var globals_instance: {
    getInstance: (applicationName: string, args?: string[]) => angular.IModule;
};
declare var test_103: {
    doIt: () => void;
};
export { globals_instance };
export { test_103 };
