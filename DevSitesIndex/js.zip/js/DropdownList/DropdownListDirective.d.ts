/// <reference path="../DataServices.d.ts" />
import * as angular from 'angular';
declare var dropdownListDirective_instance: {
    downdownList_angular_module: angular.IModule;
};
export { dropdownListDirective_instance };
