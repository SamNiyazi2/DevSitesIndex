"use strict";
// 09/24/2019 09:38 am - SSN - [20190924-0731] - [008] - Project search option
$(document).ready(function () {
    $("[ssn-cmd='search']").on("keyup", function () {
        //var val = $('#yearSelect3').val();
        //$.ajax({
        //    url: "/Holiday/Calendar",
        //    type: "GET",
        //    data: { year: ((val * 1) + 1) }
        //})
        //    .done(function (partialViewResult) {
        //        $("#refTable").html(partialViewResult);
        //    });
        alert("Have change-2019092-0939");
    });
});
alert('loaded projectIndex.js   2222');
//# sourceMappingURL=ProjectsIndex.js.map