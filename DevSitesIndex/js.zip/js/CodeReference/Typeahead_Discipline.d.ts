/// <reference types="angular" />
declare var app: angular.IModule;
