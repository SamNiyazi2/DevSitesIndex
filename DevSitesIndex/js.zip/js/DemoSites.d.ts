declare function hideFeedbackDev(fadeIn: any): void;
