// 05/19/2019 01:18 pm - SSN - [20190519-1132] - [007] - Address definitely typed errors - No errors
/// <reference path="../node_modules/@types/jquery/index.d.ts" />   
/// <reference path="../node_modules_hack/SSN_jquery_modal.d.ts" />
////////////////////////////////////////////////////////////////declare let prefixPreWithShowHideAnchor_execute: boolean;
////////////////////////////////////export class GlobalVariables {
////////////////////////////////////    public static prefixPreWithShowHideAnchor_execute: boolean= true;
////////////////////////////////////}
//08/23/2018 01:24 am - SSN
// 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
var site_instance = function () {
    // 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
    var setDefaults = function () {
        $("[cmd-name]").on('click', function (e) {
            var cmdName = $(this).attr('cmd-name');
            var popupName = $(this).attr('popup-name');
            var jQueryObjectName = $(this).attr('jQueryObjectName');
            var jQueryObjectName2 = $(this).attr('jQueryObjectName2');
            //      alert('clicked me! cmdName [' + cmdName + "] popup-name  [" + popupName + "]");
            console.log('cmd-name', cmdName, 'popupName', popupName, 'jQueryObjectName ', jQueryObjectName, 'jQueryObjectName2', jQueryObjectName2);
            if (cmdName === "open-popup") {
                console.log('exec cmdName ', cmdName);
                $(popupName).modal({ backdrop: 'static', keyboard: false });
                $("#addSite_PageContent").load("/times/start");
            }
            // 03/14/2019 09:33 am - SSN - Adding hide and show
            if (cmdName === "hideObject") {
                console.log('exec cmdName ', cmdName, 'jQueryObjectName', jQueryObjectName);
                $(jQueryObjectName).hide();
            }
            if (cmdName === "showObject") {
                console.log('exec cmdName ', cmdName, 'jQueryObjectName', jQueryObjectName);
                $(jQueryObjectName).show();
            }
            if (cmdName === "smooth-scroll") {
                //$('body').scrollspy({ target: jQueryObjectName });
                document.querySelector(jQueryObjectName).scrollIntoView({
                    behavior: 'smooth'
                });
            }
            // 04/08/2019 01:33 am - SSN - [20190407-2345] - TimeLog
            if (cmdName === "set-default-time") {
                var d = new Date();
                var cd = d.getFullYear() + "-" + p(d.getMonth() + 1, 2, '0') + "-" + p(d.getDate(), 2, '0') + "T" + p(d.getHours(), 2, '0') + ":" + p(d.getMinutes(), 2, '0') + ":" + p(d.getSeconds(), 2, '0');
                $(jQueryObjectName).val(cd);
            }
            // 04/19/2019 04:48 pm - SSN - [20190419-1647] - Set amount for TotalSeconds
            if (cmdName === "set-TotalPeriod") {
                // 05/19/2019 01:10 pm - SSN - Addressing error. string | number | string[] cannot convert top string | number
                // 05/202019 02:39 pm - SSN - No calculating elapsed time correctly with TypeScript conversion.
                var d11 = new Date();
                var selectedDate = $(jQueryObjectName)[0].value;
                var d12 = new Date(selectedDate);
                var delta_1 = d11.getTime().valueOf() - d12.getTime().valueOf();
                var delta_2 = Math.floor(delta_1 / 1000);
                $(jQueryObjectName2).val(delta_2);
            }
        });
        // 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
        // function p(str1, len, char) {
        var p = function (str1, len, char) {
            var str = str1.toString();
            if (str.length > len)
                return str;
            var s1 = char.repeat(len) + str;
            var s2 = s1.substring(len + (str.length - len));
            return s2;
        };
        // 03/14/2019 10:28 am - SSN
        $(window).on('scroll', function () {
            var y = $(window).scrollTop();
            if (y > 0) {
                $('.fixed_anchor').fadeIn('slow');
            }
            else {
                $('.fixed_anchor').fadeOut('slow');
            }
        });
        // 11/02/2019 07:25 pm - SSN - [20191101-0526] - [013] - Check login status
        // Did not finish.
        // Todo-SSN
        $('.modal').on('show', function () {
            console.log('site.ts  -  20191102-1930 - Setting draggable.');
            $(this).draggable({
                handle: ".modal-header"
            });
        });
    };
    // 08/21/2019 01:48 pm 
    // 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
    // function showCollapsedDivs() {
    var showCollapsedDivs = function () {
        $("[data-toggle='collapse']").trigger('click');
    };
    var prefixPreWithShowHideAnchor_counter = 0;
    // 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
    // function prefixPreWithShowHideAnchor() {
    var prefixPreWithShowHideAnchor = function () {
        prefixPreWithShowHideAnchor_counter += 1;
        //console.log("site.ts   prefixPreWithShowHideAnchor    GlobalVariables.prefixPreWithShowHideAnchor_execute [" + prefixPreWithShowHideAnchor_execute+ "]");
        //console.log("prefixPreWithShowHideAnchor_counter ", prefixPreWithShowHideAnchor_counter);
        //console.log(Date());
        ///////////////////////////////////////////////////  if (!prefixPreWithShowHideAnchor_execute) return;
        // 04/26/2019 09:56 pm - SSN - [20190426-2156] - [001] - Hide pre and add a link to show.
        // 06/01/2019 08:07 pm - SSN - [20190601-2007] - Add title
        $('pre').each(function (aa) {
            $(this).hide();
            var titleAttrib = "";
            var _title = $(this).attr("title");
            var _title_caption = "";
            if (_title !== undefined) {
                titleAttrib = " title='" + _title + "' ";
                _title_caption = ": " + _title;
            }
            else {
                _title = "";
            }
            $('<p><a cmd-name="showsibling" ' + titleAttrib + ' >Show code' + _title_caption + '</a></p>').insertBefore(this);
        });
        // 05/01/2019 04:52 am - SSN - Use JavaScript only
        var list1 = document.querySelectorAll('pre');
        // 05/19/2019 12:30 pm - SSN - [20190519-1132] - [004] - Address definitely typed errors
        // for (var a of list1) {
        // list1.forEach(function (currentItem, currentIndex, listObj) {
        list1.forEach(function (a, currentIndex, listObj) {
            // 05/17/2019 04:16 am - SSN - Update to exclude highlighting
            //var b = a.innerHTML.replace(/</g, '&lt;');  
            // Exclude <h and <n. Already setup for <i.  See site.css.
            // 06/07/2019 11:50 am - SSN - Update - Matches shown https://www.regextester.com/
            // var b = a.innerHTML.replace(/<([^i|^/i|^h|^/h|^n|^/n]){1}[^\s|^>]{1}/g, '&lt;$1');
            // var b = a.innerHTML.replace(/(<)((?!\/?[n|i|h]))(.*?>)/g, '\n1---\n[$&]\n2---\n[$1]\n3---\n[$2]\n4---\n[$3]\n\n');
            // We have not coverred h1, h2, etc.
            // knockout is doing its own thing when it comes to tags. Evident with the use of generic types ( function<SomeType> )
            var b = a.innerHTML.replace(/(<)((?!\/?[n|i|h]))(.*?>)/g, '&lt;$3');
            a.innerHTML = b;
        });
        // 04/26/2019 10:14 pm - SSN - [20190426-2156] - [002] - Hide pre and add a link to show.
        $("[cmd-name]").on('click', function (e) {
            var cmdName = $(this).attr('cmd-name');
            if (cmdName === "showsibling") {
                var _pre = $(this).parent().next();
                var _link = $(this);
                // 06/01/2019 08:07 pm - SSN - [20190601-2007] - Add title
                var _title = $(this).attr('title');
                var _title_caption = "";
                if (_title === undefined) {
                    _title = "";
                }
                else {
                    _title_caption = ": " + _title;
                }
                if (_pre.is(":visible")) {
                    _link.text('Show code' + _title_caption);
                    _pre.fadeOut();
                }
                else {
                    _pre.fadeIn();
                    _link.text('Hide code' + _title_caption);
                }
            }
        });
        // 11/08/2019 01:04 pm - SSN - [20191108-1043] - [008] - Persisting search on return to index
        // 
        $('[ssn-cmd=returnToCallerLink]').click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            var returnToCallerKey = $("#returnToCallerKey").val();
            document.location.href = e.target.href + "&returnToCallerKey=" + returnToCallerKey;
        });
    };
    // 04/29/2019 07:36 pm - SSN - [20190429-1748] - [006] - Angular clock out popup  - Begin
    // Source https://www.c-sharpcorner.com/UploadFile/1d3119/date-serialization-with-angular-js-web-api/
    var iso8601RegEx = /(19|20|21)\d\d([-/.])(0[1-9]|1[012])\2(0[1-9]|[12][0-9]|3[01])T(\d\d)([:/.])(\d\d)([:/.])(\d\d)/;
    // 09/21/2019 12:27 pm - SSN - [201909-1227] Revise to accommodate Babel/Webpack
    // function fnConverDate(input) {
    var fnConverDate = function (input) {
        if (typeof input !== "object")
            return input;
        for (var key in input) {
            if (!input.hasOwnProperty(key))
                continue;
            var value = input[key];
            var type = typeof value;
            var match;
            if (type === 'string' && (match = value.match(iso8601RegEx))) {
                input[key] = new Date(value);
            }
            else if (type === "object") {
                fnConverDate(value);
            }
        }
    };
    $(function () {
        setDefaults();
        // 11/08/2019 04:33 pm - SSN - Allow to bypass. Code reference.
        // 04/29/2019 07:36 pm - SSN - [20190429-1748] - [006] - Angular clock out popup  - End
        // 09/10/2019 08:53 pm - SSN - Replaced
        // 09/11/2019 07:08 am - SSN - DevSiteIndex p1 data is coming after document is ready.
        setTimeout(prefixPreWithShowHideAnchor, 2000);
        //$(function () {
        //    console.log('20190910-2054 - prefixPreWithShowHideAnchor timeout to jquery ready');
        //    prefixPreWithShowHideAnchor();
        //});
    });
    // 11/05/20191 04:53 am - SSN 
    // Need to prevent users from navigating away from Angular based pages with pending changes.
    // https://stackoverflow.com/questions/48182912/how-to-detect-browser-with-angular
    var getBrowserName = function () {
        var agent = window.navigator.userAgent.toLowerCase();
        switch (true) {
            case agent.indexOf('edge') > -1:
                return 'edge';
            case agent.indexOf('opr') > -1 && !!window.opr:
                return 'opera';
            case agent.indexOf('chrome') > -1 && !!window.chrome:
                return 'chrome';
            case agent.indexOf('trident') > -1:
                return 'ie';
            case agent.indexOf('firefox') > -1:
                return 'firefox';
            case agent.indexOf('safari') > -1:
                return 'safari';
            default:
                return 'other';
        }
    };
    var haveChanges_v03 = false;
    return {
        fnConverDate: fnConverDate,
        showCollapsedDivs: showCollapsedDivs,
        prefixPreWithShowHideAnchor: prefixPreWithShowHideAnchor,
        getBrowserName: getBrowserName,
        haveChanges_v03: haveChanges_v03
    };
}();
export { site_instance };
console.log('site - 20191104-1750');
console.log("Browser:", site_instance.getBrowserName());
// 5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36
var isChrome = site_instance.getBrowserName() === 'chrome';
if (false) {
    if (isChrome) {
        window.addEventListener("beforeunload", function (e) {
            // if (!haveChanges) return;
            var confirmationMessage = "\o/";
            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return "You will lose all pending changes if you leave this page"; //Webkit, Safari, Chrome etc.
        });
    }
    // Cannot use with Chrome
    if (!isChrome) {
        window.onbeforeunload = function (e) {
            // if (!haveChanges) return;
            var confirmationMessage = "\o/";
            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return "(2) You will lose all pending changes if you leave this page"; //Webkit, Safari, Chrome etc.
        };
    }
}
console.log('site - 20191104-1750-ZZZ');
//# sourceMappingURL=site.js.map