/// <reference path="../DataServices.d.ts" />
import * as angular from 'angular';
declare var jobsIndexController_instance: {
    Jobs_Angular_Module: angular.IModule;
};
export { jobsIndexController_instance };
