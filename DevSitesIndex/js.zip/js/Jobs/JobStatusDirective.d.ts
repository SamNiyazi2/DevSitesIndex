/// <reference types="angular" />
declare var jobStatusDirective_instance: {
    Job_Status_Angular_Module: import("angular").IModule;
};
export { jobStatusDirective_instance };
