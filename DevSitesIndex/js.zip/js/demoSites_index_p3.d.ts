/// <reference path="../node_modules_hack/SSN_jquery_modal.d.ts" />
declare var demoSites_index_p3_instance: void;
export { demoSites_index_p3_instance };
