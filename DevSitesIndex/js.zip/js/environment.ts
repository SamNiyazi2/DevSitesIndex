﻿
// 10/01/2019 09:47 am - SSN - [20191001-0944] - [003] - Adding Application Insights for JavaScript

// https://devblogs.microsoft.com/premier-developer/add-application-insights-to-an-angular-spa/

export const environment = {


    appInsights: {

        // instrumentationKey: 'd9f2121b-9475-4fd6-97cb-4df016e33ce3'
        // 10/31/2019 03:58 am - SSN - Added


        // instrumentationKey: '27233881-18ab-41ea-b5f9-f24b8ed62bd3',

        // 11/07/2019 08:34 pm - SSN - Replaced
        //    "InstrumentationKey": "deleted", "d9f2121b-9475-4fd6-97cb-4df016e33ce3" ,
        // PS-FabrikamResidences - "33c6def5-430f-4cd4-8b6f-996820820dab"
        instrumentationKey: "33c6def5-430f-4cd4-8b6f-996820820dab",


    }

};