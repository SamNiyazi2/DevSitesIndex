import * as angular from "angular";
export default interface IAngularApp {
    name: string;
    instance: angular.IModule;
}
