/// <reference path="DataServices.d.ts" />
/// <reference path="../node_modules_hack/SSN_jquery_modal.d.ts" />
import * as angular from 'angular';
declare var ssn_devsite_angular_module_instance: {
    ssn_devsite_angular_module: angular.IModule;
};
export { ssn_devsite_angular_module_instance };
