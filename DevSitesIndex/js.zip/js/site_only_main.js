// 10/04/2019 04:44 pm - SSN - To use with Angular 7.  Do we need it? (menu?)
import { site_instance } from './site';
site_instance;
//# sourceMappingURL=site_only_main.js.map