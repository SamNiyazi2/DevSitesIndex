declare var demosites_index_p1_instance: void;
export { demosites_index_p1_instance };
