/// <reference types="angular" />
declare var timesheetApp_instance: {
    timesheetApp: import("angular").IModule;
};
export { timesheetApp_instance };
