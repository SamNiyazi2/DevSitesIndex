import * as angular from "angular";
declare var timesheetController_instance: {
    timesheetApp_TimesheetController: angular.IModule;
};
export { timesheetController_instance };
