import * as angular from 'angular';
declare var timesheetClockoutController_instance: {
    timesheetApp: angular.IModule;
};
export { timesheetClockoutController_instance };
