import * as angular from 'angular';
declare var timesheetContinueController_instance: {
    timesheetApp: angular.IModule;
};
export { timesheetContinueController_instance };
